# qr-atm-system
AI Based Smart ATM
